package com.szymeqx.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import org.lwjgl.glfw.GLFW;

public class ClientMod implements ClientModInitializer {
    private boolean rshiftDown;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            long w = mc.getWindow().getHandle();

            boolean rs = GLFW.glfwGetKey(w, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (rs && !rshiftDown && mc.currentScreen == null) mc.setScreen(new ClickGui());
            rshiftDown = rs;

            for (Module m : ModuleManager.modules) {
                if (m.key > 0) {
                    boolean d = GLFW.glfwGetKey(w, m.key) == GLFW.GLFW_PRESS;
                    if (d && !m.keyDown && mc.currentScreen == null) m.toggle();
                    m.keyDown = d;
                }
                if (m.isEnabled()) m.onTick();
            }
        });

        WorldRenderEvents.LAST.register(ctx -> {
            for (Module m : ModuleManager.modules) if (m.isEnabled()) m.onRender(ctx);
        });
    }
}
