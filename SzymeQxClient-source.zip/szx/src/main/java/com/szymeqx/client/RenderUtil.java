package com.szymeqx.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.util.math.Box;
import org.joml.Matrix4f;

public class RenderUtil {
    public static BufferBuilder begin() {
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.lineWidth(1.5f);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        return Tessellator.getInstance().begin(DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
    }

    public static void end(BufferBuilder b) {
        BufferRenderer.drawWithGlobalProgram(b.end());
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    public static void line(BufferBuilder b, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2, int r, int g, int bl, int a) {
        b.vertex(m, x1, y1, z1).color(r, g, bl, a);
        b.vertex(m, x2, y2, z2).color(r, g, bl, a);
    }

    public static void box(BufferBuilder b, Matrix4f m, Box bb, int r, int g, int bl, int a) {
        float x1=(float)bb.minX,y1=(float)bb.minY,z1=(float)bb.minZ,x2=(float)bb.maxX,y2=(float)bb.maxY,z2=(float)bb.maxZ;
        float[][] c = {{x1,y1,z1},{x2,y1,z1},{x2,y1,z2},{x1,y1,z2},{x1,y2,z1},{x2,y2,z1},{x2,y2,z2},{x1,y2,z2}};
        int[][] edges = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
        for (int[] e : edges) line(b, m, c[e[0]][0], c[e[0]][1], c[e[0]][2], c[e[1]][0], c[e[1]][1], c[e[1]][2], r, g, bl, a);
    }
}
