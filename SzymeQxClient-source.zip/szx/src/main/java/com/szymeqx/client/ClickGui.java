package com.szymeqx.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ClickGui extends Screen {
    private static final int X0 = 50, Y0 = 40, W = 110, GAP = 8, HEAD = 18, ROW = 15;
    private Module binding;

    public ClickGui() { super(Text.literal("SzymeQx Client")); }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x66000000);
        ctx.drawText(textRenderer, "SzymeQx Client  |  LPM: wlacz  PPM: bind  |  Right Shift: zamknij", X0, 20, 0xFF55FFFF, true);
        int x = X0;
        for (Category c : Category.values()) {
            var list = ModuleManager.byCategory(c);
            ctx.fill(x, Y0, x + W, Y0 + HEAD, 0xEE2A2F3A);
            ctx.drawCenteredTextWithShadow(textRenderer, c.title, x + W / 2, Y0 + 5, 0xFF55E6E6);
            int y = Y0 + HEAD;
            for (Module m : list) {
                boolean hover = mx >= x && mx <= x + W && my >= y && my < y + ROW;
                int bg = m.isEnabled() ? 0xEE2E8B8B : hover ? 0xEE30343D : 0xEE15181F;
                ctx.fill(x, y, x + W, y + ROW, bg);
                ctx.drawText(textRenderer, m.name, x + 5, y + 4, 0xFFFFFFFF, false);
                String k = binding == m ? "..." : m.key > 0 ? InputUtil.fromKeyCode(m.key, 0).getLocalizedText().getString() : "";
                if (!k.isEmpty()) ctx.drawText(textRenderer, "[" + k + "]", x + W - 6 - textRenderer.getWidth("[" + k + "]"), y + 4, 0xFFAAAAAA, false);
                y += ROW;
            }
            x += W + GAP;
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int x = X0;
        for (Category c : Category.values()) {
            int y = Y0 + HEAD;
            for (Module m : ModuleManager.byCategory(c)) {
                if (mx >= x && mx <= x + W && my >= y && my < y + ROW) {
                    if (button == 0) m.toggle();
                    else if (button == 1) binding = m;
                    return true;
                }
                y += ROW;
            }
            x += W + GAP;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (binding != null) {
            binding.key = key == GLFW.GLFW_KEY_ESCAPE ? -1 : key;
            binding = null;
            return true;
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
