package com.szymeqx.client;

import java.util.*;

public class ModuleManager {
    public static final List<Module> modules = new ArrayList<>();

    public static void init() {
        // PVP
        modules.add(new Modules.KillAura());
        modules.add(new Modules.AutoTotem());
        // MOVEMENT
        modules.add(new Modules.Sprint());
        modules.add(new Modules.Flight());
        modules.add(new Modules.Step());
        modules.add(new Modules.NoFall());
        // VISUAL
        modules.add(new Modules.PlayerEsp());
        modules.add(new Modules.Tracers());
        modules.add(new Modules.NameTags());
        modules.add(new Modules.StorageEsp());
        modules.add(new Modules.ItemEsp());
        modules.add(new Modules.Fullbright());
        // UTILITY
        modules.add(new Modules.AutoRespawn());
    }

    public static List<Module> byCategory(Category c) {
        return modules.stream().filter(m -> m.category == c).toList();
    }
}
