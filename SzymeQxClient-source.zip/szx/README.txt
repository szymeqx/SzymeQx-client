SzymeQx Client - Fabric 1.21.4

JAK DOSTAC JAR (bez instalowania niczego):
1. Zaloz konto na github.com i utworz nowe repozytorium.
2. Wrzuc (Upload files) CALA zawartosc tego folderu, razem z folderem .github
3. Wejdz w zakladke Actions -> build -> poczekaj ok. 3-5 min.
4. Otworz zakonczony run -> na dole "Artifacts" -> SzymeQxClient -> pobierz.
5. Z ZIP-a wyjmij SzymeQxClient-1.0.0.jar (NIE ten -sources) i wrzuc do .minecraft/mods + Fabric API.

LOKALNIE: JDK 21 + Gradle 8.12 -> "gradle build" -> build/libs/

STEROWANIE: Right Shift = menu. LPM = wlacz modul, PPM = ustaw bind (ESC = usun bind).
